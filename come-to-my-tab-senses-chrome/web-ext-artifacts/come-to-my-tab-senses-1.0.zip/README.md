# tabs-sense

## What it does

This extension includes a browser action with a popup specified as popup/tab-senses.html

1) The popup allows the user to gather tabs from open windows.
2) Save the tabs in a copious.world user account, where the are organzed by topic
3) fetch tabs from the user account by topic
4) open a user account page

# Users Accounts

The extensions will check cookies for user account verification.

A user account will be required to fetch tabs or do further tab categorization and managent.

Tabs may be saved away within copiou.world for a limited time until a user account is established. Once a user account is established, tabs may be pinned or removed by the user.


